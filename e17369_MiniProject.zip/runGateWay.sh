javac Gateway.java
java Gateway