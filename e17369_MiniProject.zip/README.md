# CO327-Mini-Project---Vital-Monitor-System
This repository contains the code base for a vital monitor system 
